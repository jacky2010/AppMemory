#include <check.h>
#include <md5.h>
#include <base64.h>
#include <sstream>
#include <string>

char* jstringTostring(JNIEnv* env, jstring jstr) {
	char* rtn = NULL;
	jclass clsstring = env->FindClass("java/lang/String");
	jstring strencode = env->NewStringUTF("utf-8");
	jmethodID mid = env->GetMethodID(clsstring, "getBytes",
			"(Ljava/lang/String;)[B");
	jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
	jsize alen = env->GetArrayLength(barr);
	jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);
	if (alen > 0) {
		rtn = (char*) malloc(alen + 1);
		memcpy(rtn, ba, alen);
		rtn[alen] = 0;
	}
	env->ReleaseByteArrayElements(barr, ba, 0);
	return rtn;
}

char* checkX(JNIEnv* env, jobject obj) {
	jclass cls = env->FindClass("android/content/Context");
	jmethodID mid = env->GetMethodID(cls, "getPackageManager",
			"()Landroid/content/pm/PackageManager;");
	jobject pm = env->CallObjectMethod(obj, mid);
	mid = env->GetMethodID(cls, "getPackageName", "()Ljava/lang/String;");

	jstring packageName = (jstring) env->CallObjectMethod(obj, mid);
	cls = env->GetObjectClass(pm);
	mid = env->GetMethodID(cls, "getPackageInfo",
			"(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");

	jobject packageInfo = env->CallObjectMethod(pm, mid, packageName, 0x40);

	cls = env->GetObjectClass(packageInfo);
	jfieldID fid = env->GetFieldID(cls, "signatures",
			"[Landroid/content/pm/Signature;");
	jobjectArray signatures = (jobjectArray) env->GetObjectField(packageInfo,
			fid);
	jobject sign = env->GetObjectArrayElement(signatures, 0);

	cls = env->GetObjectClass(sign);
	mid = env->GetMethodID(cls, "toCharsString", "()Ljava/lang/String;");

	jstring signString = (jstring) env->CallObjectMethod(sign, mid);
	return jstringTostring(env, signString);
}

char* checkAAA(JNIEnv* env, jobject obj, char* str) {
	char* _load = checkX(env, obj);
	std::string output;
	output.append(_load);
	output.append(str);
	std::string strData = base64_encode(reinterpret_cast<const unsigned char*>(output.c_str()), output.length());
	char * _str = const_cast<char*>(strData.data());
	char aaa[8] = {'f','5','8','6','A','r', 'W', 0};
	std::string checkaaa;
	checkaaa.append(aaa);
	checkaaa.append(_str);
	char * _checkaaa = const_cast<char*>(checkaaa.data());
	char* destination = MD5String(_checkaaa);
	return destination;
}

char* checkBBB(JNIEnv* env, jobject obj, char* _str) {
	char aaa[8] = {'1','e','V','b','m','o', '5', 0};
	std::string checkaaa;
	checkaaa.append(_str);
	checkaaa.append(aaa);
	char * _checkaaa = const_cast<char*>(checkaaa.data());
	char* destination = MD5String(_checkaaa);
	return destination;
}

char* checkCCC(JNIEnv* env, jobject obj, char* _str) {
	char aaa[8] = {'T','s','7','6','h','I', 'L', 0};
	std::string checkaaa;
	checkaaa.append(aaa);
	checkaaa.append(_str);
	char * _checkaaa = const_cast<char*>(checkaaa.data());
	char* destination = MD5String(_checkaaa);
	return destination;
}

jstring xorenkeyJ(JNIEnv* env, jobject thiz, char *_message, char *key) {
	jclass cls = env->FindClass("com/hdvietpro/bigcoin/network/HDVRequest");
	jmethodID mid = env->GetMethodID(cls, "encodeXor",
			"(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
	jstring j = (jstring) env->CallObjectMethod(thiz, mid, env->NewStringUTF(_message),
			env->NewStringUTF(key));
    return j;
}

jstring xordekeyJ(JNIEnv* env, jobject thiz, char *_message, char *key) {
	jclass cls = env->FindClass("com/hdvietpro/bigcoin/network/HDVRequest");
	jmethodID mid = env->GetMethodID(cls, "decodeXor",
			"(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
	jstring j = (jstring) env->CallObjectMethod(thiz, mid, env->NewStringUTF(_message),
			env->NewStringUTF(key));
	return j;
}

char * xorenkey(JNIEnv* env, jobject thiz, char *_message, char *key) {
	jstring j = xorenkeyJ(env, thiz, _message, key);
	char* _j = const_cast<char*>(env->GetStringUTFChars(j, JNI_FALSE));
    return _j;
}

char * xordekey(JNIEnv* env, jobject thiz, char *_message, char *key) {
	jstring j = xordekeyJ(env, thiz, _message, key);
	char* _j = const_cast<char*>(env->GetStringUTFChars(j, JNI_FALSE));
	return _j;
}

jstring encodeBase64Str(JNIEnv* env, jobject thiz, char *_message) {
	jclass cls = env->FindClass("com/hdvietpro/bigcoin/network/HDVRequest");
	jmethodID mid = env->GetMethodID(cls, "encodeBase64Str",
			"(Ljava/lang/String;)Ljava/lang/String;");
	jstring j = (jstring) env->CallObjectMethod(thiz, mid, env->NewStringUTF(_message));
	return j;
}

