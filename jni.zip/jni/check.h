#include <jni.h>

char* jstringTostring(JNIEnv* env, jstring jstr);
char* checkX(JNIEnv* env, jobject obj);
char* checkAAA(JNIEnv* env, jobject obj, char* str);
char* checkBBB(JNIEnv* env, jobject obj, char* str);
char* checkCCC(JNIEnv* env, jobject obj, char* str);
char * xorenkey(JNIEnv* env, jobject thiz, char *_message, char *key);
char * xordekey(JNIEnv* env, jobject thiz, char *_message, char *key);
jstring xorenkeyJ(JNIEnv* env, jobject thiz, char *_message, char *key);
jstring xordekeyJ(JNIEnv* env, jobject thiz, char *_message, char *key);
jstring encodeBase64Str(JNIEnv* env, jobject thiz, char *_message);
