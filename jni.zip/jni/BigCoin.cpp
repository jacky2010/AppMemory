#include <base64.h>
#include <jni.h>
#include <md5.h>
#include <string>
#include <sstream>
#include <android/log.h>

extern "C" {

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_decodeString(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring data) {
	std::string strKeyBuild;
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	strKeyBuild.append(_keyBuild);
	if (isCheckKeyBuild(_keyBuild) == 1 || isCheckKeyBuildInviteFB(_keyBuild) == 1) {
		char* _data = const_cast<char*>(env->GetStringUTFChars(data, JNI_FALSE));

		std::string strInput;
		strInput.append(_data);
		std::string strData = base64_decode(strInput);

		char key[13] = { 'a', 'n', 'h', 'm', 'a', 'n', 'h', 'v', 'o', 'd', 'i', 'c', 'h' };
		std::string output = strData;

		for (int i = 0; i < strData.size(); i++)
			output[i] = strData[i] ^ key[i % (sizeof(key) / sizeof(char))];

		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		env->ReleaseStringUTFChars(data, _data);
		return (env)->NewStringUTF(output.data());
	}else{
		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		std::string returnStr = std::string("hjf34JH34ds889JHfds34dsfs34nma098fH3rlaTDasd89");
		return (env)->NewStringUTF(returnStr.data());
	}
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_encodeString(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring data) {
	std::string strKeyBuild;
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	strKeyBuild.append(_keyBuild);
	if (isCheckKeyBuild(_keyBuild) == 1 || isCheckKeyBuildInviteFB(_keyBuild) == 1) {
		char* _data = const_cast<char*>(env->GetStringUTFChars(data, JNI_FALSE));

		std::string strData;
		strData.append(_data);

		char key[13] = { 'a', 'n', 'h', 'm', 'a', 'n', 'h', 'v', 'o', 'd', 'i', 'c', 'h' };
		std::string output = strData;

		for (int i = 0; i < strData.size(); i++)
			output[i] = strData[i] ^ key[i % (sizeof(key) / sizeof(char))];

		std::string strEncode = base64_encode(
				reinterpret_cast<const unsigned char*>(output.c_str()),
				output.length());

		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		env->ReleaseStringUTFChars(data, _data);
		return (env)->NewStringUTF(strEncode.data());
	}else{
		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		std::string returnStr = std::string("hjf34JH34ds889JHfds34dsfs34nma098fH3rlaTDasd89");
		return (env)->NewStringUTF(returnStr.data());
	}
}

jstring Java_com_hdvietpro_bigcoin_network_HDVRequest_encodeServer(JNIEnv* env,
		jobject thiz, jobject obj, jstring keyBuild, jstring data, jstring time) {
	char* z = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	if (isCheckKeyBuild(z) == 1 || isCheckKeyBuildInviteFB(z) == 1) {
		char* a = checkAAA(env, obj, z);
		char* b = checkBBB(env, obj, a);
		char* c = checkCCC(env, obj, b);

		std::string d;
		d.append(b);
		d.append(a);
		d.append(c);

		char* i = const_cast<char*>(env->GetStringUTFChars(data, JNI_FALSE));
		jstring js = encodeBase64Str(env, thiz, i);
		char* s = const_cast<char*>(env->GetStringUTFChars(js, JNI_FALSE));
		std::string j;
		j.append(s);
		std::stringstream ss;
		ss << j.size();
		d.append(ss.str());

		char* t = const_cast<char*>(env->GetStringUTFChars(time, JNI_FALSE));
		d.append(t);
		char k[18] = { 'A', 'n', 'h', 'M', 'a', 'n', 'h', 'V', '0', 'D', 'j', 'c', 'h', '6', '8', '6', '8', 0};
		d.append(k);

		std::string temp;
		temp.append(t);
		temp.append(ss.str());
		char* _temp = MD5String(const_cast<char*> (temp.data()));
		char* h = const_cast<char*>(d.data());
		h = xorenkey(env, thiz, h, _temp);

		char* e = xorenkey(env, thiz, i, h);
		std::string f;
		f.append(e);

		env->ReleaseStringUTFChars(keyBuild, z);
		env->ReleaseStringUTFChars(data, i);
		env->ReleaseStringUTFChars(time, t);
		return (env)->NewStringUTF(f.data());
	}else{
		env->ReleaseStringUTFChars(keyBuild, z);
		std::string returnStr = std::string("hjf34JH34ds889JHfds34dsfs34nma098fH3rlaTDasd89");
		return (env)->NewStringUTF(returnStr.data());
	}
}

jstring Java_com_hdvietpro_bigcoin_network_HDVRequest_decodeServer(JNIEnv* env,
		jobject thiz, jobject obj, jstring keyBuild, jstring data, jstring time) {
	char* z = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	if (isCheckKeyBuild(z) == 1 || isCheckKeyBuildInviteFB(z) == 1) {
		char* a = checkAAA(env, obj, z);
		char* b = checkBBB(env, obj, a);
		char* c = checkCCC(env, obj, b);

		std::string d;
		d.append(b);
		d.append(a);
		d.append(c);

		char* i = const_cast<char*>(env->GetStringUTFChars(data, JNI_FALSE));

		std::string dt;
		dt.append(i);
		std::stringstream ss;
		ss << dt.size();
		d.append(ss.str());

		char* t = const_cast<char*>(env->GetStringUTFChars(time, JNI_FALSE));
		d.append(t);
		char k[18] = { 'A', 'n', 'h', 'M', 'a', 'n', 'h', 'V', '0', 'D', 'j', 'c', 'h', '6', '8', '6', '8', 0};
		d.append(k);

		std::string temp;
		temp.append(t);
		temp.append(ss.str());
		char* _temp = MD5String(const_cast<char*> (temp.data()));
		char* h = const_cast<char*>(d.data());
		h = xorenkey(env, thiz, h, _temp);

		char* e = xordekey(env, thiz, i, h);
		std::string f;
		f.append(e);

		env->ReleaseStringUTFChars(keyBuild, z);
		env->ReleaseStringUTFChars(data, i);
		env->ReleaseStringUTFChars(time, t);
		return (env)->NewStringUTF(f.data());
	}else{
		env->ReleaseStringUTFChars(keyBuild, z);
		std::string returnStr = std::string("hjf34JH34ds889JHfds34dsfs34nma098fH3rlaTDasd89");
		return (env)->NewStringUTF(returnStr.data());
	}
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_encodeServer(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring data) {
	std::string strKeyBuild;
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	strKeyBuild.append(_keyBuild);
	if (isCheckKeyBuild(_keyBuild) == 1) {
		char* input = const_cast<char*>(env->GetStringUTFChars(data, JNI_FALSE));

		size_t len = strlen(input);
		char s[len + 1];
		for (int i = 0; i < len; i++) {
			char asciValue = input[i];
			if (asciValue >= 65 && asciValue < 126) {
				asciValue++;
				s[i] = asciValue;
			} else {
				s[i] = input[i];
			}
		}
		s[len] = 0;
		std::string strEncode = s;

		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		env->ReleaseStringUTFChars(data, input);
		return (env)->NewStringUTF(strEncode.data());
	}else{
		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		std::string returnStr = std::string("hjf34JH34ds889JHfds34dsfs34nma098fH3rlaTDasd89");
		return (env)->NewStringUTF(returnStr.data());
	}
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_decodeServer(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring data) {
	std::string strKeyBuild;
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	strKeyBuild.append(_keyBuild);
	if (isCheckKeyBuild(_keyBuild) == 1) {
		char* str = const_cast<char*>(env->GetStringUTFChars(data, JNI_FALSE));

		size_t len = strlen(str);
		char s[len + 1];
		for (int i = 0; i < len; i++) {
			int asciValue = str[i];
			if (asciValue >= 66 && asciValue < 127) {
				asciValue--;
				s[i] = asciValue;
			} else {
				s[i] = str[i];
			}
		}
		s[len] = 0; // end string
		std::string strDecode = s;

		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		env->ReleaseStringUTFChars(data, str);
		return (env)->NewStringUTF(strDecode.data());
	}else{
		env->ReleaseStringUTFChars(keyBuild, _keyBuild);
		std::string returnStr = std::string("hjf34JH34ds889JHfds34dsfs34nma098fH3rlaTDasd89");
		return (env)->NewStringUTF(returnStr.data());
	}
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_registerGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = registerApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_loginGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = loginApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkTypeLoginGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkTypeloginApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_reloadCoinGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = reloadCoinApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getControlBigcoinGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getControlBigcoin(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListCampaignGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListCampaign(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getInfoAppGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getInfoApp(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_logOpenAppGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = logOpenApp(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_logBlackListAppGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = logBlackListApp(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkBonusInstallAppGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkBonusInstallApp(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkBonusOpenAppGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkBonusOpenApp(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_moneyExchangeGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = moneyExchange(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getHistoryMoneyExchangeGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getHistoryMoneyExchange(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getHistoryBonusInstallGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getHistoryBonusInstall(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getHistoryWaitInstallGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getHistoryWaitInstall(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_changeCostGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = changeCost(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getInfoAllGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getInfoAll(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListEventCampaignGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListEventCampaign(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkAnswerEventGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkAnswerEvent(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkAllBonusUserGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkAllBonusUser(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkClickAdsUserGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkClickAdsUser(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkViewPopupUserGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkViewPopupUser(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkWatchAdsGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkWatchAds(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkShareFacebookGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkShareFacebook(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkRotateGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkRotate(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkInviteFriendGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkInviteFriend(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_trackingClickViewPopupGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = trackingClickViewPopupGetApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_trackingInstallGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = trackingInstallGetApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getFQAGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getFQAGetApiKey(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_sendPhoneNumberGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = sendPhoneNumber(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_sendActiveCodeGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = sendActiveCode(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListTypeBonusGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListTypeBonus(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_sendGCMIdGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = sendGCMId(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListTypeFeedbackGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListTypeFeedback(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_sendFeedbackGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = sendFeedback(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getNotifyGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getNotify(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getNotifyDetailGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getNotifyDetail(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListYoutubeChannelGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListYoutubeChannel(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListFanpageGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListFanpage(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListGroupFBGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getListGroupFB(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_logJoinGroupFBGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = logJoinGroupFB(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_logSubscribeNotBigCoinGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = logSubscribeNotBigCoin(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_logLikePageNotBigCoinGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = logLikePageNotBigCoin(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getTopRankUserGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getTopRankUser(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_sendInviteCodeGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = sendInviteCode(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_sendVirtualDeviceInfoGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = sendVirtualDeviceInfo(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_extraInfoUserGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = extraInfoUser(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getAppViewInfoGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getAppViewInfo(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_checkViewAppBonusGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = checkViewAppBonus(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_detailCampaignGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = detailCampaign(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getCampaignQuestionGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = getCampaignQuestion(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_clientResponseNotifyGetApiKey(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = clientResponseNotify(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}









jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_inviteAppConfig(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = inviteApp_config(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_inviteAppChangeCostCodeInvite(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = inviteApp_changeCostCodeInvite(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}

jstring Java_com_hdvietpro_bigcoin_util_SecurityUtil_getListAppInvite(JNIEnv* env,
		jobject thiz, jstring keyBuild, jstring deviceID, jstring timestemp,
		jstring timeserver) {
	char* _keyBuild = const_cast<char*>(env->GetStringUTFChars(keyBuild, JNI_FALSE));
	char* _deviceID = const_cast<char*>(env->GetStringUTFChars(deviceID, JNI_FALSE));
	char* _timestemp = const_cast<char*>(env->GetStringUTFChars(timestemp, JNI_FALSE));
	char* _timeserver = const_cast<char*>(env->GetStringUTFChars(timeserver, JNI_FALSE));
	std::string apiKey = inviteApp_getListAppInvite(_keyBuild, _deviceID, _timestemp, _timeserver);
	jstring resultApiKey = (env)->NewStringUTF(apiKey.data());
	env->ReleaseStringUTFChars(keyBuild, _keyBuild);
	env->ReleaseStringUTFChars(deviceID, _deviceID);
	env->ReleaseStringUTFChars(timestemp, _timestemp);
	env->ReleaseStringUTFChars(timeserver, _timeserver);
	return resultApiKey;
}


}
