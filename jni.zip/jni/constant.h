class constant {
public:

#define HDV_KEY_LOGIN "bdhfg@dafkf89";

#define HDV_KEY_CHECK_TYPE_LOGIN "swdj@dheandroid_dweifhe8";

#define HDV_KEY_REGISTER "sa@swidh283duwgd"

#define HDV_KEY_RELOAD_COIN "ksjdwdwswsn@45.56"

#define HDV_KEY_CONTROL_BIGCOIN "bigcoin@conreol.2sd";

#define HDV_KEY_LIST_CAMPAIGN "capgns45@hn";

#define HDV_KEY_INFO_APP "info23h.kn";

#define HDV_KEY_DETAIL_CAMPAIGN "dl@hjokj";

#define HDV_KEY_CAMPAIGN_QUESTION "hr0a3tCAucz";

#define HDV_KEY_LOG_OPEN_APP "fjf76@487udeuf";

#define HDV_KEY_LOG_BLACKLIST "w@sd.deidhi3d";

#define HDV_KEY_CHECK_CLICK_CAMPAIGN "clicks@hj82d";

#define HDV_KEY_CHECK_BONUS_INSTALL_APP "eded98.@dehe";

#define HDV_KEY_CHECK_BONUS_OPEN_APP "cnie@sdlf.cf384";

#define HDV_KEY_MONEY_EXCHANGE "vevu@f4985fifjir";

#define HDV_KEY_MONEY_EXCHANGE_HISTORY "ijhu@sd123sd";

#define HDV_KEY_USER_CHECK_ALL_BONUS "bxws@swded.342";

#define HDV_KEY_USER_CLICK "od23.sss@defi";

#define HDV_KEY_USER_VIEW_POPUP "okoi98s@dsssqi";

#define HDV_KEY_USER_WATCH_ADS "@dsdeifh@.fjqi";

#define HDV_KEY_USER_SHARE "213dneieh.swsjo@q";

#define HDV_KEY_USER_ROTATE "bxws@ded.342";

#define HDV_KEY_USER_INVITE_FRIEND "123ddwdwidhwudw237284ei.@ded";

#define HDV_KEY_TRACKING_CLICK_VIEWPOPUP "swidt.e3oj@u9";

#define HDV_KEY_TRACKING_INSTALL "seeuhf@ieheaishwhd";

#define HDV_KEY_GET_FQA "vnoo989@defie";

#define HDV_KEY_LIST_TYPE_BONUS "re_dfd.s2he@sd345";

#define HDV_KEY_SEND_PHONE_NUMBER "12de34@wd.efef";

#define HDV_KEY_SEND_CODE "kojhn@as213";

#define HDV_KEY_CHANGE_COST "vnrigh823@der48";

#define HDV_KEY_BONUS_INSTALL_APPS "bonus_install_a@pps.cost.8u9";

#define HDV_KEY_CHANGE_ROTATE "bxws@ded.342";

#define HDV_KEY_HISTORY_BONUS "swuhd22df.@sd";

#define HDV_KEY_HISTORY_WAIT "dedh.w@wdhwid";

#define HDV_KEY_INFO_ALL "123ddei.@ded";

#define HDV_KEY_LIST_EVENT_CAMPAIGN "vTM3mko3xCC@android";

#define HDV_KEY_CHECK_ANSWER_EVENT "2CipHhWcLlo@android";

#define HDV_KEY_SEND_TOKEN_ID "dkeo@asw12d4";

#define HDV_KEY_CLIENT_RESPONSE_NOTIFY "fonr@ed343dehe";

#define HDV_KEY_GET_NOTIFY "aij@dw.65sws";

#define HDV_KEY_GET_NOTIFY_DETAIL "aij@ddddw.65sws";

#define HDV_KEY_GET_LIST_TYPE_FEEDBACK "virhihg@ofj923dwd";

#define HDV_KEY_FEEDBACK "swiscdheihf@d.453";

#define HDV_KEY_GET_LIST_YOUTUBE_CHANNEL "def45d@dehdiehd";

#define HDV_KEY_GET_LIST_FAN_PAGE "vni@hv45defie";

#define HDV_KEY_GET_LIST_GROUP_FB "list_1group3*#s_fb";

#define HDV_KEY_LOG_JOIN_GROUP_FB "as311212*#s_fb";

#define HDV_KEY_LOG_SUBSCRIBE_NOT_BIGCOIN "adwidh@234.d";

#define HDV_KEY_LOG_LIKE_NOT_BIGCOIN "74efei.ef@iehf";

#define HDV_KEY_TOP_RATING_USER "sdfj@nskd98";

#define HDV_KEY_SEND_INVITE_CODE "ijh2.gs@34d";

#define HDV_KEY_EXTRA_INFO_USER "jhgu@koi9";

#define HDV_KEY_EXTRA_VIRTUAL_DEVICE_INFO "crur@swihf948";

#define HDV_KEY_VIEW_APP "skdc.2sdf@dehfi";

#define HDV_KEY_BONUS_VIEW_APP "cehgijg@rig87dufu";

#define HDV_ACTION_LOGIN "ldfhh@sd8723dhf";

#define HDV_ACTION_CHECK_TYPE_LOGIN "ecbdfe7637androidfrf@ds";

#define HDV_ACTION_REGISTER "djaaduhu@ww1273hdw";

#define HDV_ACTION_RELOAD_COIN "lo90eff8.23@23";

#define HDV_ACTION_CONTROL_BIGCOIN "control_bg";

#define HDV_ACTION_LIST_CAMPAIGN "list_campaign";

#define HDV_ACTION_INFO_APP "getinfoapp";

#define HDV_ACTION_DETAIL_CAMPAIGN "detail_cp";

#define HDV_ACTION_CAMPAIGN_QUESTION "a@campa!ign_q";

#define HDV_ACTION_LOG_OPEN_APP "vbws123@swihdiwh";

#define HDV_ACTION_LOG_BLACKLIST "dedhu@deheid.sws";

#define HDV_ACTION_CHECK_CLICK_CAMPAIGN "user_click";

#define HDV_ACTION_CHECK_BONUS_INSTALL_APP "cks.id@de2398";

#define HDV_ACTION_CHECK_BONUS_OPEN_APP "ceh@hssd.34ddf";

#define HDV_ACTION_MONEY_EXCHANGE "ccbeugf@dihdwihda2";

#define HDV_ACTION_MONEY_EXCHANGE_HISTORY "hi234.df4";

#define HDV_ACTION_USER_CHECK_ALL_BONUS "ojf@eidswje.29fe8";

#define HDV_ACTION_USER_CLICK "cheas2ac.2s";

#define HDV_ACTION_USER_VIEW_POPUP "shdkf12de.2s";

#define HDV_ACTION_USER_WATCH_ADS "sdeude@idhed.2s";

#define HDV_ACTION_USER_SHARE "bsucg@dwid.3444";

#define HDV_ACTION_USER_ROTATE "ojf@eidje.29fe8";

#define HDV_ACTION_USER_INVITE_FRIEND "inswdwudw";

#define HDV_ACTION_TRACKING_CLICK_VIEWPOPUP "12swugduwgd";

#define HDV_ACTION_TRACKING_INSTALL "ihfeufhu29389283";

#define HDV_ACTION_GET_FQA "jdwcwnb@dc";

#define HDV_ACTION_LIST_TYPE_BONUS "ty_b234@xdf";

#define HDV_ACTION_CHANGE_COST "sccbhe@swidhiwd82";

#define HDV_ACTION_BONUS_INSTALL_APPS "bonus_install_apps";

#define HDV_ACTION_CHANGE_ROTATE "ojf@eidje.29fe8";

#define HDV_ACTION_HISTORY_BONUS "his.34@jdhf";

#define HDV_ACTION_HISTORY_WAIT "sws@sw834";

#define HDV_ACTION_INFO_ALL "ins34d.@34";

#define HDV_ACTION_LIST_EVENT_CAMPAIGN "list_campai@gn_event";

#define HDV_ACTION_CHECK_ANSWER_EVENT "check_bonus_answer@android";

#define HDV_ACTION_SEND_PHONE_NUMBER "cnih@434den.swd";

#define HDV_ACTION_SEND_CODE "send_c@df45s";

#define HDV_ACTION_SEND_TOKEN_ID "tod.sd@23dne";

#define HDV_ACTION_CLIENT_RESPONSE_NOTIFY "cliswd@swidh123";

#define HDV_ACTION_GET_NOTIFY "swdc34@23";

#define HDV_ACTION_GET_NOTIFY_DETAIL "swdc34dd@23";

#define HDV_ACTION_GET_LIST_TYPE_FEEDBACK "deihfie@wojd";

#define HDV_ACTION_FEEDBACK "fe3948d3@34";

#define HDV_ACTION_GET_LIST_YOUTUBE_CHANNEL "wdwd@ojojw344";

#define HDV_ACTION_GET_LIST_FAN_PAGE "jeih@d34dc";

#define HDV_ACTION_GET_LIST_GROUP_FB "list_groups_fb";

#define HDV_ACTION_LOG_JOIN_GROUP_FB "tracking_join_group";

#define HDV_ACTION_SUBSCRIBE_NOT_BIGCOIN "dwhd@dhwid";

#define HDV_ACTION_LIKE_NOT_BIGCOIN "wdwd2@sd.d";

#define HDV_ACTION_TOP_RATING_USER "t_allmnj@12";

#define HDV_ACTION_SEND_INVITE_CODE "se987@kijg";

#define HDV_ACTION_EXTRA_INFO_USER "ex_i981@as";

#define HDV_ACTION_EXTRA_VIRTUAL_DEVICE_INFO "virtdedhe@dei";

#define HDV_ACTION_VIEW_APP "cbegf@sa@cnd";

#define HDV_ACTION_BONUS_VIEW_APP "dehue@5986hfehf";

};
